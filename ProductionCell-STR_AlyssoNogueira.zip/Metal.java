	//package ProductionCell;

public class Metal {
	
	boolean Forjado = false;
	
	Metal(){
		
		System.out.println("Novo Metal Criado");
		
	}
}
